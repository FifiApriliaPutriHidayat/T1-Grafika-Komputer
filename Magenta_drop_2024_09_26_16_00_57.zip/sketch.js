function setup() {
  createCanvas(400, 120);
}

function draw() {
  background(200);
  ellipse(120,60,60,60);
  ellipse(200,60,60,60);
}