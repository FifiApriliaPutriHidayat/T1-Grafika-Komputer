function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(255,192,203);
  rect(100,100,100,100);
  
}